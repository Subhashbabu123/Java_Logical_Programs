package com.bitlabs.ArogyaHospital;

public class App 
{
    public static void main( String[] args )
    {
    	DaoInterface dao=new DaoImpl();
        Patient p=new Patient();
        
        /*p.setId(101);
        p.setAge(20);
        p.setName("banka");
        p.setGender("male");
        p.setCity("vizag");
        p.setAddress("4-408,eluru");
        p.setGuardian_name("balaji");
        p.setGuardian_address("2-57");
        p.setDateOfAdmission("2001/09/12");
        p.setAadhar_Card_number(1234525);
        p.setContact_number(9600069);
        p.setGuardian_contactNumber(74323444);*/
        
        //dao.patientRegistartion(p);
        
        //dao.viewAllPatient();
        
        //dao.searchPatientById(102);
        
        //dao.deletePatientById(101);
        
        dao.searchPatientByCity("guntur");
        
        //dao.searchPatientByAgeGroup(18, 55);
    }
}
